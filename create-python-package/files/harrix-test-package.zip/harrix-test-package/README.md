# harrix-test-package

Test package.

## Install

```console
pip install harrix-test-package
```

## Using

```py
import harrixtestpackage as h


print(h.multiply_2(2))
```
